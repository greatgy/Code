$(function(){$("#box-nav").lavaLamp({fx:"backout",speed:700,click:function(){return!0}})});
