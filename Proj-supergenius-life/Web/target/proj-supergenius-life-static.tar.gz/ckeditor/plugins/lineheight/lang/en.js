CKEDITOR.plugins.setLang('lineheight','en', {
    title: '行高'
} );
